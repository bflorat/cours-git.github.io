package com.mycompany.app;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;
/**
 * Calcul
 *
 */
public class Calcul 
{
    static Logger logger = Logger.getLogger(Calcul.class);

	/**
 	  * une méthode add qui fonctionne 
	*/
	public static int add(int a, int b) {
		return a + b;
	}

	/** 
	  * une erreur s'est glissée ici dû à un copier coller du add...
	*/
	public static int sub(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
        	BasicConfigurator.configure();
		logger.info("Hello World");          // the old SysO-statement
		
		int a = 1 ;
		int b = 2 ;
		int c;
		c = Calcul.add (a, b);
		System.out.println("Le résultat de l addition entre a="+ a+" et b="+ b+" est c="+c);

	}
}
