package com.mycompany.app;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class CalculTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public CalculTest( String testName )
    {
        super( testName );
		// ce constructeur est obligatoire car il n'existe pas 
		// de constructeur par defaut dans les TestCase
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( CalculTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }

	/* !!! Attention si on utilise pas junit4 il faut que les méthodes des tests commencent par test...
	*/
	//	@Test
	public void testAdd() {
		int a = 1; 
		int b = 2;
		int c = 3;
		assertEquals(c, Calcul.add(a, b));

	}

	public void testSub() {
		int a = 1; 
		int b = 2;
		int c = 1;
		assertEquals(c, Calcul.sub(b, a));

	}


}
